struct Studentas {
    string Vard, 
    string Pav;
    std::vector<int> paz = { 0 };
    int egz;
    float GP = 0;
};
  //string vardas;
	//string pavarde;
	//int pazymiuSk;
	//vector <int>pazymiai;
	//double ndVid; //namu darbu vidurkis
	//double mediana; //namu darbu mediana
	//int egzaminas; //egzamino rezultatas
//double galutinis;
	//double galutinisMed;